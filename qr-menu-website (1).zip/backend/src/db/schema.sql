-- Single-restaurant schema — no tenant/restaurant_id columns anywhere.

CREATE TABLE IF NOT EXISTS tables (
  id TEXT PRIMARY KEY,
  label TEXT NOT NULL,
  qr_token TEXT NOT NULL UNIQUE,
  active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS orders (
  id TEXT PRIMARY KEY,
  order_number TEXT NOT NULL,
  table_token TEXT,
  order_type TEXT NOT NULL CHECK (order_type IN ('DINE_IN', 'TAKEAWAY')),
  status TEXT NOT NULL DEFAULT 'RECEIVED'
    CHECK (status IN ('RECEIVED','PREPARING','READY','COMPLETED','CANCELLED')),
  customer_name TEXT,
  customer_phone TEXT,
  items_json TEXT NOT NULL,   -- snapshot of items as submitted: [{menuItemId,name,unitPrice,qty}]
  subtotal INTEGER NOT NULL,
  tax INTEGER NOT NULL,
  total INTEGER NOT NULL,
  pos_order_id TEXT,
  pos_bill_number TEXT,
  pos_sync_status TEXT NOT NULL DEFAULT 'PENDING'
    CHECK (pos_sync_status IN ('PENDING','SYNCED','FAILED')),
  pos_sync_attempts INTEGER NOT NULL DEFAULT 0,
  pos_last_error TEXT,
  idempotency_key TEXT NOT NULL UNIQUE,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
