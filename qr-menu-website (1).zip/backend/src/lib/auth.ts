import type { Env } from "../types";

/**
 * Minimal admin auth for a single-restaurant staff panel: a shared password
 * set as a Worker secret, sent as `Authorization: Bearer <password>`.
 * Fine for one restaurant's staff; swap for real per-user auth if headcount grows.
 */
export function isAuthorized(req: Request, env: Env): boolean {
  const header = req.headers.get("Authorization") ?? "";
  const token = header.replace(/^Bearer\s+/i, "");
  return !!env.ADMIN_PASSWORD && token === env.ADMIN_PASSWORD;
}
