import type { Env } from "../../types";
import type { PosAdapter } from "./types";
import { mockAdapter } from "./mockAdapter";
// Once you've built a real adapter (see templateAdapter.ts), import it
// here and add a case below, e.g.:
// import { petpoojaAdapter } from "./petpoojaAdapter";

export function getPosAdapter(env: Env): PosAdapter {
  switch (env.POS_PROVIDER) {
    // case "petpooja":
    //   return petpoojaAdapter;
    case "mock":
    default:
      return mockAdapter;
  }
}
