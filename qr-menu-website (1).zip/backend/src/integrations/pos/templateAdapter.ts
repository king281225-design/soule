import type { Env } from "../../types";
import type { PosAdapter, PushOrderInput, PushOrderResult } from "./types";
import { PosError } from "./types";

/**
 * TEMPLATE — copy this file to e.g. petpoojaAdapter.ts / posistAdapter.ts /
 * squareAdapter.ts once you've picked a billing system, fill in the marked
 * sections using that POS's API docs, then register it in index.ts (see
 * the comment there). Nothing else in the codebase needs to change.
 *
 * Steps for a new POS integration:
 *   1. Get API docs/credentials for this specific restaurant's account.
 *   2. Fill in buildOrderPayload() and parseOrderResponse() below to match
 *      that API's request/response shape.
 *   3. Set the required secrets: wrangler secret put POS_API_KEY (etc.)
 *   4. Set POS_API_BASE_URL and POS_PROVIDER in wrangler.toml.
 *   5. Register the adapter in src/index.ts.
 */
export const templateAdapter: PosAdapter = {
  async pushOrder(env: Env, input: PushOrderInput): Promise<PushOrderResult> {
    // ---- FILL IN: build the request body this POS's "create order" API expects ----
    const payload = {
      // example shape — replace with the real fields from the POS docs
      external_order_id: input.internalOrderId,
      order_type: input.orderType,
      table: input.tableLabel ?? null,
      customer_name: input.customerName ?? null,
      customer_phone: input.customerPhone ?? null,
      items: input.items.map((i) => ({
        name: i.name,
        quantity: i.qty,
        price: i.unitPrice,
      })),
      subtotal: input.subtotal,
      tax: input.tax,
      total: input.total,
    };

    let res: Response;
    try {
      res = await fetch(`${env.POS_API_BASE_URL}/orders`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          // ---- FILL IN: this POS's auth headers ----
          // Authorization: `Bearer ${env.POS_API_KEY}`,
        },
        body: JSON.stringify(payload),
      });
    } catch (err) {
      throw new PosError(`Network error calling POS: ${err}`, true);
    }

    if (res.status >= 500 || res.status === 429) {
      throw new PosError(`POS server error: ${res.status}`, true);
    }
    if (!res.ok) {
      const body = await res.text().catch(() => "");
      throw new PosError(`POS rejected order: ${res.status} ${body}`, false);
    }

    const json: any = await res.json();

    // ---- FILL IN: pull the order/bill id out of this POS's response shape ----
    return {
      posOrderId: json.order_id ?? json.id ?? "",
      posBillNumber: json.bill_number ?? json.receipt_number,
      raw: json,
    };
  },
};
