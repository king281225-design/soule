import type { Env } from "../../types";

/**
 * This is the ONE interface the rest of the app depends on. Whichever
 * billing/POS software you end up using (Petpooja, Posist, Square, or
 * something else), you implement this interface once and nothing else
 * in the codebase needs to change — routes, database, and the frontend
 * are all written against this contract, not against any specific POS.
 */

export interface PosOrderItem {
  name: string;
  qty: number;
  unitPrice: number;
}

export interface PushOrderInput {
  internalOrderId: string;
  orderType: "DINE_IN" | "TAKEAWAY";
  tableLabel?: string;
  customerName?: string;
  customerPhone?: string;
  items: PosOrderItem[];
  subtotal: number;
  tax: number;
  total: number;
}

export interface PushOrderResult {
  posOrderId: string;
  posBillNumber?: string;
  raw: unknown;
}

export class PosError extends Error {
  constructor(
    message: string,
    public readonly retryable: boolean,
  ) {
    super(message);
  }
}

export interface PosAdapter {
  pushOrder(env: Env, input: PushOrderInput): Promise<PushOrderResult>;
}
