import type { Env } from "../../types";
import type { PosAdapter, PushOrderInput, PushOrderResult } from "./types";

/**
 * Default adapter when POS_PROVIDER=mock (the default in wrangler.toml).
 * Simulates a successful POS push after a short delay, so you can test
 * the entire ordering flow — cart, checkout, confirmation, status page —
 * before any billing software has been chosen or configured.
 */
export const mockAdapter: PosAdapter = {
  async pushOrder(_env: Env, input: PushOrderInput): Promise<PushOrderResult> {
    await new Promise((r) => setTimeout(r, 150));
    return {
      posOrderId: `MOCK-${input.internalOrderId.slice(0, 8)}`,
      posBillNumber: `BILL-${Math.floor(1000 + Math.random() * 9000)}`,
      raw: { mock: true },
    };
  },
};
