import type { Env } from "../types";
import { getPosAdapter } from "./pos/registry";
import { PosError } from "./pos/types";

const MAX_ATTEMPTS = 8;

export async function runPosSyncRetrySweep(env: Env) {
  const pending = await env.DB.prepare(
    `SELECT id, order_type, table_token, customer_name, customer_phone, items_json, subtotal, tax, total, pos_sync_attempts
     FROM orders WHERE pos_sync_status = 'PENDING' AND pos_sync_attempts < ?
     ORDER BY created_at ASC LIMIT 20`,
  )
    .bind(MAX_ATTEMPTS)
    .all();

  const adapter = getPosAdapter(env);

  for (const order of pending.results as any[]) {
    let tableLabel: string | undefined;
    if (order.table_token) {
      const table = await env.DB.prepare(`SELECT label FROM tables WHERE qr_token = ?`)
        .bind(order.table_token)
        .first<{ label: string }>();
      tableLabel = table?.label;
    }

    try {
      const result = await adapter.pushOrder(env, {
        internalOrderId: order.id,
        orderType: order.order_type,
        tableLabel,
        customerName: order.customer_name ?? undefined,
        customerPhone: order.customer_phone ?? undefined,
        items: JSON.parse(order.items_json),
        subtotal: order.subtotal,
        tax: order.tax,
        total: order.total,
      });

      await env.DB.prepare(
        `UPDATE orders SET pos_order_id = ?, pos_bill_number = ?, pos_sync_status = 'SYNCED', updated_at = datetime('now') WHERE id = ?`,
      )
        .bind(result.posOrderId, result.posBillNumber ?? null, order.id)
        .run();
    } catch (err) {
      const retryable = err instanceof PosError ? err.retryable : true;
      const attempts = order.pos_sync_attempts + 1;
      const status = retryable && attempts < MAX_ATTEMPTS ? "PENDING" : "FAILED";
      await env.DB.prepare(
        `UPDATE orders SET pos_sync_status = ?, pos_sync_attempts = ?, pos_last_error = ?, updated_at = datetime('now') WHERE id = ?`,
      )
        .bind(status, attempts, String(err), order.id)
        .run();
    }
  }
}
