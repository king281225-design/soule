import type { Env, PlaceOrderBody } from "../types";
import { json } from "../lib/response";
import { getPosAdapter } from "../integrations/pos/registry";
import { PosError } from "../integrations/pos/types";

export async function handlePlaceOrder(req: Request, env: Env) {
  let body: PlaceOrderBody;
  try {
    body = await req.json();
  } catch {
    return json({ error: "Invalid JSON body" }, { status: 400 });
  }

  if (!body.idempotencyKey || !Array.isArray(body.items) || body.items.length === 0) {
    return json({ error: "idempotencyKey and at least one item are required" }, { status: 400 });
  }

  // Idempotency: return the existing order if this key was already processed.
  const existing = await env.DB.prepare(
    `SELECT id, order_number, status, total, pos_bill_number, pos_sync_status
     FROM orders WHERE idempotency_key = ?`,
  )
    .bind(body.idempotencyKey)
    .first<any>();
  if (existing) return json(toConfirmation(existing));

  // NOTE: this simple backend trusts the prices the frontend sends (they
  // come from data.js, which is public source). If you later add an admin
  // panel with prices in D1, re-validate against that here instead — see
  // the fuller reference app's orders.ts for the pattern.

  let tableLabel: string | undefined;
  if (body.orderType === "DINE_IN") {
    if (!body.tableToken) return json({ error: "tableToken is required for dine-in orders" }, { status: 400 });
    const table = await env.DB.prepare(`SELECT label FROM tables WHERE qr_token = ? AND active = 1`)
      .bind(body.tableToken)
      .first<{ label: string }>();
    if (!table) return json({ error: "Invalid or inactive table" }, { status: 400 });
    tableLabel = table.label;
  }

  const orderId = crypto.randomUUID();
  const orderNumber = `#${Math.floor(1000 + Math.random() * 9000)}`;

  await env.DB.prepare(
    `INSERT INTO orders
      (id, order_number, table_token, order_type, status, customer_name, customer_phone,
       items_json, subtotal, tax, total, pos_sync_status, idempotency_key)
     VALUES (?, ?, ?, ?, 'RECEIVED', ?, ?, ?, ?, ?, ?, 'PENDING', ?)`,
  )
    .bind(
      orderId,
      orderNumber,
      body.tableToken ?? null,
      body.orderType,
      body.customerName ?? null,
      body.customerPhone ?? null,
      JSON.stringify(body.items),
      body.subtotal,
      body.tax,
      body.total,
      body.idempotencyKey,
    )
    .run();

  let posBillNumber: string | undefined;
  let posSyncStatus: "PENDING" | "SYNCED" | "FAILED" = "PENDING";

  try {
    const adapter = getPosAdapter(env);
    const result = await adapter.pushOrder(env, {
      internalOrderId: orderId,
      orderType: body.orderType,
      tableLabel,
      customerName: body.customerName,
      customerPhone: body.customerPhone,
      items: body.items.map((i) => ({ name: i.name, qty: i.qty, unitPrice: i.unitPrice })),
      subtotal: body.subtotal,
      tax: body.tax,
      total: body.total,
    });

    posBillNumber = result.posBillNumber;
    posSyncStatus = "SYNCED";

    await env.DB.prepare(
      `UPDATE orders SET pos_order_id = ?, pos_bill_number = ?, pos_sync_status = 'SYNCED', updated_at = datetime('now') WHERE id = ?`,
    )
      .bind(result.posOrderId, result.posBillNumber ?? null, orderId)
      .run();
  } catch (err) {
    const retryable = err instanceof PosError ? err.retryable : true;
    posSyncStatus = retryable ? "PENDING" : "FAILED";
    await env.DB.prepare(
      `UPDATE orders SET pos_sync_status = ?, pos_sync_attempts = pos_sync_attempts + 1, pos_last_error = ?, updated_at = datetime('now') WHERE id = ?`,
    )
      .bind(posSyncStatus, String(err), orderId)
      .run();
    // Order is still confirmed to the customer — POS sync retries in the background.
  }

  const itemCount = body.items.reduce((n, i) => n + i.qty, 0);

  return json({
    orderId,
    orderNumber,
    status: "RECEIVED",
    itemCount,
    total: body.total,
    posBillNumber,
    posSyncStatus,
  });
}

export async function handleGetOrderStatus(_req: Request, env: Env, params: { orderId: string }) {
  const order = await env.DB.prepare(
    `SELECT id, order_number, status, total, pos_bill_number, pos_sync_status FROM orders WHERE id = ?`,
  )
    .bind(params.orderId)
    .first<any>();

  if (!order) return json({ error: "Order not found" }, { status: 404 });
  return json(toConfirmation(order));
}

function toConfirmation(row: any) {
  return {
    orderId: row.id,
    orderNumber: row.order_number,
    status: row.status,
    total: row.total,
    posBillNumber: row.pos_bill_number ?? undefined,
    posSyncStatus: row.pos_sync_status,
  };
}
