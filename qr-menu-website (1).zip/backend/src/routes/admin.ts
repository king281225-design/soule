import type { Env } from "../types";
import { json } from "../lib/response";
import { isAuthorized } from "../lib/auth";

function unauthorized() {
  return json({ error: "Unauthorized" }, { status: 401 });
}

export async function handleAdminListOrders(req: Request, env: Env) {
  if (!isAuthorized(req, env)) return unauthorized();

  const url = new URL(req.url);
  const status = url.searchParams.get("status");

  const query = status
    ? env.DB.prepare(
        `SELECT id, order_number, status, order_type, table_token, customer_name, total,
                pos_bill_number, pos_sync_status, created_at
         FROM orders WHERE status = ? ORDER BY created_at DESC LIMIT 100`,
      ).bind(status)
    : env.DB.prepare(
        `SELECT id, order_number, status, order_type, table_token, customer_name, total,
                pos_bill_number, pos_sync_status, created_at
         FROM orders ORDER BY created_at DESC LIMIT 100`,
      );

  const orders = await query.all();
  return json(orders.results);
}

export async function handleAdminUpdateOrderStatus(req: Request, env: Env, params: { orderId: string }) {
  if (!isAuthorized(req, env)) return unauthorized();

  const body = await req.json<{ status: string }>();
  const allowed = ["RECEIVED", "PREPARING", "READY", "COMPLETED", "CANCELLED"];
  if (!allowed.includes(body.status)) return json({ error: "Invalid status" }, { status: 400 });

  await env.DB.prepare(`UPDATE orders SET status = ?, updated_at = datetime('now') WHERE id = ?`)
    .bind(body.status, params.orderId)
    .run();

  return json({ ok: true });
}

export async function handleAdminCreateTable(req: Request, env: Env) {
  if (!isAuthorized(req, env)) return unauthorized();

  const body = await req.json<{ label: string }>();
  if (!body.label) return json({ error: "label is required" }, { status: 400 });

  const id = crypto.randomUUID();
  const qrToken = crypto.randomUUID().replace(/-/g, "").slice(0, 10);

  await env.DB.prepare(`INSERT INTO tables (id, label, qr_token, active) VALUES (?, ?, ?, 1)`)
    .bind(id, body.label, qrToken)
    .run();

  return json({ id, label: body.label, qrToken });
}

export async function handleAdminListTables(req: Request, env: Env) {
  if (!isAuthorized(req, env)) return unauthorized();
  const tables = await env.DB.prepare(`SELECT id, label, qr_token as qrToken, active FROM tables`).all();
  return json(tables.results);
}
