import type { Env } from "../types";
import { json } from "../lib/response";

export async function handleGetTable(_req: Request, env: Env, params: { token: string }) {
  const table = await env.DB.prepare(`SELECT id, label FROM tables WHERE qr_token = ? AND active = 1`)
    .bind(params.token)
    .first<{ id: string; label: string }>();

  if (!table) return json({ error: "Unknown or inactive table" }, { status: 404 });
  return json({ tableId: table.id, label: table.label });
}
